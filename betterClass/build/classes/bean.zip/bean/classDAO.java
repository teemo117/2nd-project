package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

//CRUD 중심으로 기능을 정의
//데이터와 관련된 작업(Data Access object : DAO)
public class classDAO {
	// 기능을 정의할 때는 메서드(함수)를 사용한다.
	Connection con;
	DBConnectionMgr dbcp;
	static int cNumOfRegist = 0;
	public classDAO() throws Exception {
//		con = dbcp.getConnection();// DB프로그램 절차에 맞게 코딩
		// 1. connector 설정
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. connector 연결");
		// 2. db연결
		// String url "연결하는방법://ip:port/db명";
		String url = "jdbc:mysql://localhost:3366/bc?useUnicode=true&characterEncoding=utf8";
		String user = "root";
		String password = "1234";
		con = DriverManager.getConnection(url, user, password);

		System.out.println("2. db연결성공!");
	}

	public boolean create(classVO vo) throws Exception {
		// 강의 등록
		String sql = "insert into class(cTitle,cType,cAddress,cInfo,cLimit,cPrice,cCurriculum,tID,cImg,tCrt,cDate,cTime,cDay) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		System.out.println("3. sql문 생성 성공");
		String tID = "jw123";
		
		ps.setString(1, vo.getcTitle());
		ps.setString(2, vo.getcType());
		ps.setString(3, vo.getcAddress());
		ps.setString(4, vo.getcInfo());
		ps.setInt(5, vo.getcLimit());
		ps.setInt(6, vo.getcPrice());
		ps.setString(7, vo.getcCurriculum());
		ps.setString(8, tID);
		ps.setString(9, vo.getcImg());
		ps.setString(10, vo.gettCrt());
		ps.setString(11, vo.getcDate());
		ps.setString(12, vo.getcTime());
		ps.setString(13, vo.getcDay());

		int row = ps.executeUpdate();
		System.out.println("4. sql전송 성공");
		boolean result = false;
		if (row == 1) {
			result = true;
		}
		con.close();
		ps.close();
		return result;

	}
	public int getCnumOfRegist(int cCode) throws Exception {
		//현 수강인원 출력하기
		String sql = "select cNumOfRegist from class where cCode = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, cCode);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			cNumOfRegist = rs.getInt("cNumOfRegist");
		}
		
		con.close();
		ps.close();
		return cNumOfRegist;

	}
	public boolean create2(classVO vo) throws Exception {
		// 강의 등록
		String sql2 = "update class set cNumOfRegist = ? where cCode = ?";
		PreparedStatement ps2 = con.prepareStatement(sql2);
		System.out.println("3. sql문 생성 성공");
		
		ps2.setInt(1, cNumOfRegist + vo.getcNumOfRegist());
		ps2.setInt(2, vo.getcCode());
		
		int row = ps2.executeUpdate();
		System.out.println("4. sql전송 성공");
		boolean result = false;
		if (row == 1) {
			result = true;
		}
		con.close();
		ps2.close();
		return result;

	}

	public ArrayList<classVO> all(int cCode) throws Exception {
		// 3. sql문을 만든다.
		String sql = "select * from class where cCode = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, cCode);

		// 4. sql문은 전송
		ResultSet rs = ps.executeQuery();
		System.out.println("4. SQL문 전송 성공.!!");
		ArrayList<classVO> list = new ArrayList<classVO>();
		while (rs.next()) { // 결과가 있는지 없는지 체크해주는 메서드
			classVO bag = new classVO();// 가방만들어서,
			bag.setcTitle(rs.getString("cTitle"));
			bag.setcType(rs.getString("cType"));
			bag.setcDate(rs.getString("cDate"));
			bag.setcTime(rs.getString("cTime"));
			bag.setcDay(rs.getString("cDay"));
			bag.setcLimit(rs.getInt("cLimit"));
			bag.setcInfo(rs.getString("cInfo"));
			bag.setcCurriculum(rs.getString("cCurriculum"));
			bag.setcAddress(rs.getString("cAddress"));
			bag.setcPrice(rs.getInt("cPrice"));
			bag.settCrt(rs.getString("tCrt"));
			bag.setcImg(rs.getString("cImg"));
			
			list.add(bag);
		}
		return list;
	}
}